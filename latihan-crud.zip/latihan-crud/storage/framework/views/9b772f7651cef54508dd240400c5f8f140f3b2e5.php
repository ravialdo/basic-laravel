<?php $__env->startSection('content'); ?>

		<?php if(session('sukses')): ?>

			<div class="alert alert-success mt-5" role="alert">
			  <?php echo e(session('sukses')); ?>

			</div>

		<?php endif; ?>

		<h1 class=" mt-5">Data Buku Alamat</h1>

		<!-- Button trigger modal -->
		<button type="button" class="btn btn-primary btn-sm float-right mb-3" data-toggle="modal" data-target="#exampleModal">
		  + Tambah
		</button>

		<?php if( count($data_siswa) > 0 ): ?>

			<?php $i = 1; ?>
		
			<table class="table table-hover">
			  <thead>
			    <tr>
		          <th scope="col">No</th>
			      <th scope="col">Nama</th>
			      <th scope="col">Umur</th>
			      <th scope="col">Alamat</th>
			      <th scope="col">Aksi</th>
			    </tr>
			  </thead>
			  <tbody>
			   
			      <?php $__currentLoopData = $data_siswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $siswa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

					<tr>
						<td> <?php echo e($i); ?> </td>
						<td> <?php echo e($siswa->nama); ?> </td>
						<td> <?php echo e($siswa->umur); ?> </td>
						<td> <?php echo e($siswa->alamat); ?> </td>
						<td> 
							<a href="/siswa/<?php echo e($siswa->id); ?>/update" class="btn btn-warning btn-sm" role="button">Edit</a>
							<a href="/siswa/<?php echo e($siswa->id); ?>/delete" class="btn btn-danger btn-sm" role="button" onclick="return confirm('Are you sure you want to delete?')">Hapus</a>
						</td>
					</tr>

					<?php $i++; ?>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			<?php endif; ?>

			    </tbody>	
			</table>

	</div>

		<!-- Modal -->
		<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
		      </div>
		      <div class="modal-body">
		       		
		      		<form method="POST" action="/siswa/create" autocomplete="off">
		      			<?php echo e(csrf_field()); ?>


						  <div class="form-group">
						    <label>Nama</label>
						    <input name="nama" type="text" class="form-control" placeholder="Masukan Nama?" required="on" pattern="[a-z A-Z]+">						   
						  </div>

						  <div class="form-group">
						    <label>Umur</label>
						    <input name="umur" type="text" class="form-control" placeholder="Masukan Umur?" required="on">
						  </div>

						    <div class="form-group">
						    <label>Alamat</label>
						    <input name="alamat" type="text" class="form-control" placeholder="Masukan Alamat?" required="on">
						  </div>
						  

		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-dark" data-dismiss="modal">Batal</button>
		        <button type="submit" class="btn btn-success float-right">Tambahkan</button>

					</form>
		      </div>
		    </div>
		  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>