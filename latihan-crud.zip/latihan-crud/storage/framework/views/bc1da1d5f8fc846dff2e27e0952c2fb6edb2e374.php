<?php $__env->startSection('content'); ?>

		<div class="row justify-content-center">
			<div class="col-md-6">

				<h1 class="m-3">Edit Data Buku Alamat</h1>
				
				<form method="POST" action="/siswa/<?php echo e($siswa->id); ?>/update">
		      			<?php echo e(csrf_field()); ?>


						  <div class="form-group">
						    <label>Nama</label>
						    <input name="nama" type="text" class="form-control" value="<?php echo e($siswa->nama); ?>">						   
						  </div>

						  <div class="form-group">
						    <label>Umur</label>
						    <input name="umur" type="text" class="form-control" value="<?php echo e($siswa->umur); ?>">
						    <div class="form-group">
						    	
						    <label>Alamat</label>
						    <input name="alamat" type="text" class="form-control" value="<?php echo e($siswa->alamat); ?>">
						  </div>
						  

		      </div>
		    
		        <button type="reset" class="btn btn-dark">Bersihkan</button>
		        <button type="submit" class="btn btn-success float-right">Update</button>

					</form>
			</div>
		</div>
		
<?php $__env->stopSection(); ?>
<?php echo $__env->make("layout.master", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>