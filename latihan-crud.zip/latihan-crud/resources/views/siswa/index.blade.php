@extends("layout.master")

@section('content')

		@if(session('sukses'))

			<div class="alert alert-success mt-5" role="alert">
			  {{ session('sukses') }}
			</div>

		@endif

		<h1 class=" mt-5">Data Buku Alamat</h1>

		<!-- Button trigger modal -->
		<button type="button" class="btn btn-primary btn-sm float-right mb-3" data-toggle="modal" data-target="#exampleModal">
		  + Tambah
		</button>

		@if( count($data_siswa) > 0 )

			<?php $i = 1; ?>
		
			<table class="table table-hover">
			  <thead>
			    <tr>
		          <th scope="col">No</th>
			      <th scope="col">Nama</th>
			      <th scope="col">Umur</th>
			      <th scope="col">Alamat</th>
			      <th scope="col">Aksi</th>
			    </tr>
			  </thead>
			  <tbody>
			   
			      @foreach($data_siswa as $siswa)

					<tr>
						<td> {{ $i }} </td>
						<td> {{ $siswa->nama }} </td>
						<td> {{ $siswa->umur }} </td>
						<td> {{ $siswa->alamat }} </td>
						<td> 
							<a href="/siswa/{{$siswa->id}}/update" class="btn btn-warning btn-sm" role="button">Edit</a>
							<a href="/siswa/{{$siswa->id}}/delete" class="btn btn-danger btn-sm" role="button" onclick="return confirm('Are you sure you want to delete?')">Hapus</a>
						</td>
					</tr>

					<?php $i++; ?>

					@endforeach

			@endif

			    </tbody>	
			</table>

	</div>

		<!-- Modal -->
		<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
		  <div class="modal-dialog" role="document">
		    <div class="modal-content">
		      <div class="modal-header">
		        <h5 class="modal-title" id="exampleModalLabel">Tambah Data</h5>
		        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
		          <span aria-hidden="true">&times;</span>
		        </button>
		      </div>
		      <div class="modal-body">
		       		
		      		<form method="POST" action="/siswa/create" autocomplete="off">
		      			{{ csrf_field() }}

						  <div class="form-group">
						    <label>Nama</label>
						    <input name="nama" type="text" class="form-control" placeholder="Masukan Nama?" required="on" pattern="[a-z A-Z]+">						   
						  </div>

						  <div class="form-group">
						    <label>Umur</label>
						    <input name="umur" type="text" class="form-control" placeholder="Masukan Umur?" required="on">
						  </div>

						    <div class="form-group">
						    <label>Alamat</label>
						    <input name="alamat" type="text" class="form-control" placeholder="Masukan Alamat?" required="on">
						  </div>
						  

		      </div>
		      <div class="modal-footer">
		        <button type="button" class="btn btn-dark" data-dismiss="modal">Batal</button>
		        <button type="submit" class="btn btn-success float-right">Tambahkan</button>

					</form>
		      </div>
		    </div>
		  </div>

@endsection